# File Upload / Download service  

* Project is entirely built on Python and Django REST Framework. 
* This Project is used to upload files and those files can be viewed only by the user who uploads it.
