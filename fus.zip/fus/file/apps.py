from django.apps import AppConfig  # pragma: no cover


class FileConfig(AppConfig):  # pragma: no cover
    name = 'file'  # pragma: no cover
